# rlm_eap_fast
## Metadata
<dl>
  <dt>category</dt><dd>authentication</dd>
</dl>

## Summary
Implements [RFC 4851](https://tools.ietf.org/html/rfc4851),
Cisco's EAP-FAST (Flexible Authentication via Secure Tunnelling)
protocol.
