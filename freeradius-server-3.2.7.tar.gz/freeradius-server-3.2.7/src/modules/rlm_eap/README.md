# rlm_eap
## Metadata
<dl>
  <dt>category</dt><dd>authentication</dd>
</dl>

## Summary

Implements the base protocol for EAP (Extensible Authentication Protocol).

EAP is commonly used to authenticate 802.1X and PPP (Point to Point Protocol) sessions.
