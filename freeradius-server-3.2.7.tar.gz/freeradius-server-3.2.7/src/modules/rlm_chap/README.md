# rlm_chap
## Metadata
<dl>
  <dt>category</dt><dd>authentication</dd>
</dl>

## Summary

Performs Challenge Handshake Authentication Protocol (CHAP) authentication, as described by RFC 2865.
