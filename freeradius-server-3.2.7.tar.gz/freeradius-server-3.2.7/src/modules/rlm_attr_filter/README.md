# rlm_attr_filter
## Metadata
<dl>
  <dt>category</dt><dd>policy</dd>
</dl>

## Summary

Filters attributes in a request. Can delete attributes or permit them to have only certain values.
