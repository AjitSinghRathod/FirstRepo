# rlm_counter
## Metadata
<dl>
  <dt>category</dt><dd>policy</dd>
</dl>

## Summary

Provides a way to count items, one counter per unique key. For
example with User-Name for the key and Acct-Session-Time as the
count attribute, the length of time each user may use per day
could be limited.
