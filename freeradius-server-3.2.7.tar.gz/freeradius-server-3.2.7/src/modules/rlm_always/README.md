# rlm_always
## Metadata
<dl>
  <dt>category</dt><dd>policy</dd>
</dl>

## Summary

Returns a pre-configured result code such as 'ok', 'noop',
'reject' etc. May be configured at runtime via an XLAT expression.
