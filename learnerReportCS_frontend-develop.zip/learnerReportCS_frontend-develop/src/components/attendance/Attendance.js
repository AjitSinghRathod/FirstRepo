import React from 'react'
import GetQuestions from '../getQuestions/GetQuestions'
import Students from '../students/Students'

const Attendance = () => {
  return (
    <>
        <GetQuestions />
    </>
  )
}

export default Attendance