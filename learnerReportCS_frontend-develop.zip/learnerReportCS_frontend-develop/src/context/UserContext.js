import { createContext } from "react";

const User = createContext(null);

export default User;

